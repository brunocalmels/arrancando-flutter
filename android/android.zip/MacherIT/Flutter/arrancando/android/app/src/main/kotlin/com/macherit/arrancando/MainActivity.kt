package com.macherit.arrancando

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
