package com.baseflow.geolocator.location;

public enum LocationAccuracy {
  lowest,
  low,
  medium,
  high,
  best,
  bestForNavigation
}
